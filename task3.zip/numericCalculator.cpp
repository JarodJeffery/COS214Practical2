#include "numericCalculator.h"

numericCalculator::numericCalculator()
{
}

numericCalculator::numericCalculator(int h, double w, float b)
{
    height =h;
    weight =w;
    bend = b;
}

string numericCalculator::performCalculation()
{
    return 0;
}
