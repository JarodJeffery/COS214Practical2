#include "testable.h"

testable::testable()
{
}

bool testable::runTest()
{
    return false;
}
