#include "booleanCalculator.h"

booleanCalculator::booleanCalculator()
{
}

string booleanCalculator::performCalculation()
{
    return false;
}