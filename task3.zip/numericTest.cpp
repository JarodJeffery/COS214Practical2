#include <string>
#include <iostream>
#include "test.h"
#include "numericCalculator.h"
#include "numericTest.h"

numericTest::numericTest()
{
}

bool numericTest::executeTest()
{
    numericCalculator nc(height, weight, bend);
    return false;
}