#include "test.h"

test::test()
{
}

test::test(int h, double w, float b)
{
    height =h;
    weight = w;
    bend = b;
}

bool test::executeTest()
{
    return false;
}
