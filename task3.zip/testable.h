#ifndef TESTABLE_H
#define TESTABLE_H
#include <string>
#include<iostream>

using namespace std;
class testable{
    public:
        testable();
        bool runTest();
};

#endif