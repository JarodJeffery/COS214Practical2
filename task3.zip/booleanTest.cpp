#include "booleanTest.h"

bool booleanTest::executeTest()
{
    return false;
}