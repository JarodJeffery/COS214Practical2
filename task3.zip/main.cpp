#include<iostream>
#include<string>
#include"afterTest.h"
#include"beforeTest.h"
#include"testable.h"
#include"testBed.h"
#include"numericTest.h"
#include"booleanTest.h"
#include"booleanCalculator.h"
#include"numericCalculator.h"

int main(){

    return 0;
}