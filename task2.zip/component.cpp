#include "component.h"

void component::print()
{
}

double component::getTotalExpenditure()
{
    return 0.0;
}

double component::getExpenditureByCostCenter()
{
    return 0.0;
}

component::~component()
{
    delete this;
}
