#include "Completed.h"
#include "Contract.h"

void Completed::addCondition(Contract* contract, const std::string& conditionDetails) {

}

void Completed::removeCondition(Contract* contract, const std::string& conditionDetails) {

}

void Completed::acceptContract(Contract* contract) {

}

void Completed::rejectContract(Contract* contract) {

}

void Completed::completeContract(Contract* contract) {

}

std::string Completed::toString() const {
    return "State: COMPLETED\n";
}
